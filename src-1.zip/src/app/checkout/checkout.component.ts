import { Component, OnInit } from '@angular/core';
import { transactions } from '../transactions';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  
  transaction:transactions;
  transactionType:String;
  price:number;
  remarks:String;
  constructor(private dataService: Itemservice){}

  ngOnInit(): void {
  }
  
  checkout()
  {
    console.log("in checout.ts")
    this.transaction = new transactions();
    this.transaction.price=this.price;
    this.transaction.remarks=this.remarks;
    this.transaction.transactionType=this.transactionType;
    this.dataService.checckout(this.transaction).subscribe(transactions=>this.transaction=transactions);
  }

}
