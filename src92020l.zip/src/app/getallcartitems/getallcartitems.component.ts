import { Component, OnInit, Input } from '@angular/core';
import { cartitems } from '../cartitem';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-getallcartitems',
  templateUrl: './getallcartitems.component.html',
  styleUrls: ['./getallcartitems.component.css']
})
export class GetallcartitemsComponent implements OnInit {
  cartitemses:cartitems[];
  cartitem1:cartitems;
  quantity:number=0;
  show:boolean=false;
  cartItemId:number;
  constructor(private dataService: Itemservice){}
  @Input() cartitem = new cartitems();
  ngOnInit(): void {
    this.dataService.getAllitems().subscribe(cartitems=>{this.cartitemses=cartitems;
     
    });
    
    
  }
  
  increment(items:cartitems)
  {
    console.log("incrementing");
    items.quantity=items.quantity+1;
    items.price = items.price*items.quantity;
    this.cartItemId=items.cartItemId;
    this.cartitem1 = new cartitems();
    this.cartitem1.quantity=items.quantity;
    this.cartitem1.price=items.price;
    this.dataService.updatecartitem(this.cartitem1,this.cartItemId).subscribe(cartitems=>this.cartitemses=cartitems);
    console.log(items.price);
  }
  decrement(items:cartitems)
  {
    console.log("decrement");
    items.quantity=items.quantity-1;
    items.price = items.price*items.quantity;
    this.cartItemId=items.cartItemId;
    this.cartitem1 = new cartitems();
    this.cartitem1.quantity=items.quantity;
    this.cartitem1.price=items.price;
    this.dataService.updatecartitem(this.cartitem1,this.cartItemId).subscribe(cartitems=>this.cartitemses=cartitems);

  }
  delete(items:cartitems)
  {
    console.log("in delete");
    console.log(items.cartItemId);
    this.dataService.deletecartitem(items.cartItemId).subscribe(cartitems=>this.cartitemses=cartitems);
  }

}
