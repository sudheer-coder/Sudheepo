import { Component, OnInit } from '@angular/core';
import { Itemservice } from '../Items.service';
import { Itemlist } from '../Itemsearch';

@Component({
  selector: 'app-additems',
  templateUrl: './additems.component.html',
  styleUrls: ['./additems.component.css']
})
export class AdditemsComponent implements OnInit {
  deleteditem:number;
  itemId:number;
  productName:String;
  manufacturer:String;
  model:String;
  price:number;
  quantity:number;
  description:String;
  picture:String;
  items:Itemlist = new Itemlist();
  constructor(private dataService: Itemservice){}

  ngOnInit(): void {
  } 
  additems() 
  {
    this.items.productName=this.productName;
    this.items.manufacturer=this.manufacturer;
    this.items.model=this.model;
    this.items.price=this.price;
    this.items.quantity=this.quantity;
    this.items.description=this.description;
    this.items.picture=this.picture;
    this.dataService.additems(this.items).subscribe(Itemlist=>this.items=Itemlist);
  } 
  deleteitem() 
  { 
    console.log("in .ts");
    this.dataService.deleteitem(this.deleteditem).subscribe(Itemlist=>this.items=this.items)
  }
  updateitem() 
  {
    console.log("in update");
    this.items.productName=this.productName;
    this.items.manufacturer=this.manufacturer;
    this.items.model=this.model;
    this.items.price=this.price;
    this.items.quantity=this.quantity;
    this.items.description=this.description;
    this.items.picture=this.picture;
    this.itemId=2;
    this.dataService.updateitems(this.items,this.itemId).subscribe(Itemlist=>this.items=this.items);
  }

}
