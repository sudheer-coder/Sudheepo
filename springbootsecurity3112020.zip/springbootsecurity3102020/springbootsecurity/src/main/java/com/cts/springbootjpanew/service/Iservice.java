package com.cts.springbootjpanew.service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.cts.springbootjpanew.entity.BuyerDetails;
import com.cts.springbootjpanew.entity.CartItems;
import com.cts.springbootjpanew.entity.PurchaseHistory;
import com.cts.springbootjpanew.entity.TransactionHistory;
@Service
public interface Iservice {
	//Buyers
    List<BuyerDetails> getAll();
	BuyerDetails add(BuyerDetails buyerdetails);
	BuyerDetails getUser(int id);
	BuyerDetails updateBuyer(BuyerDetails buyerdetails,int id);
	BuyerDetails findOne(String username);
	
	//Items
	List<CartItems> getAllItems();
	CartItems addcart(CartItems cartItems,int id);
	CartItems getItem(int id);
	CartItems updateItem(CartItems cartItems,int id);
	void  deleteByIds(int id,int bid);
	void  deleteAllItem();
	
	
	//Transactions
	List<TransactionHistory> getAllTransaction();
	TransactionHistory addcartItems(TransactionHistory transactonhistory,int id);
	TransactionHistory getTransaction(int id);
	TransactionHistory updateTransaction(TransactionHistory transactionhistory,int id);
	
	
	//purchasehistory
	List<PurchaseHistory> getPurchase();
	PurchaseHistory addPurchase(PurchaseHistory purchasehistory,int id,int ids);
	PurchaseHistory getpurchase(int id);
	PurchaseHistory updatePurchase(PurchaseHistory purchasehistory,int id);
	
	
	//checkout
	TransactionHistory checkout(TransactionHistory transactonhistory,int ids);
	
	
}
