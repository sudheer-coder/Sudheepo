import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { AdditemsComponent } from './additems/additems.component';
import { GetallcartitemsComponent } from './getallcartitems/getallcartitems.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { NavigationbarComponent } from './navigationbar/navigationbar.component';
import { LoginformComponent } from './loginform/loginform.component';


const routes: Routes = [
  {path:'additem',component: AdditemsComponent},
  {path:'navigation/buyersignup',component: UsersignupComponent},
  {path:'sellersignup',component: SellersignupComponent},
  {path:'cartitems',component: GetallcartitemsComponent},
  {path:'checkout',component: CheckoutComponent},
  {path:'navigation',component: NavigationbarComponent},
  {path:'Login',component: LoginformComponent}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }