package com.seller.entity;

public class ItemSearch {

	private String prodname;
	public ItemSearch() 
	{ 
		
	}
	public ItemSearch(String prodname) {
		super();
		this.prodname = prodname;
	}
	public String getProdname() {
		return prodname;
	}
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	@Override
	public String toString() {
		return "ItemSearch [prodname=" + prodname + "]";
	}

}
