package com.seller.Dao;




import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.seller.entity.Items;
@Repository

public interface ItemsDao extends JpaRepository<Items, Integer>{
	@Modifying
	@Transactional
	@Query(value="delete from Items where item_id=?1 and seller_id=?2",nativeQuery = true)
	public void deleteItem(int iid,int sid);

}
