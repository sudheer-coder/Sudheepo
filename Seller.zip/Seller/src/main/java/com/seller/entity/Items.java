package com.seller.entity;

public class Items {

}
