package com.seller.service;

import java.util.List;

import com.seller.entity.Items;
import com.seller.entity.SellerDetails;

public interface SellerService {
	//seller
	SellerDetails add(SellerDetails sellerDetails);
	List<SellerDetails> getAll();
	SellerDetails updateBuyer(SellerDetails sellerDetails,int sid);
	
	//items
	Items addItems(Items items,int sid,int subid,int catid);
	Items updateItem(Items item,int pid);
	List<Items> getAllItems();
	String deleteItem(int iid,int sid);
}
