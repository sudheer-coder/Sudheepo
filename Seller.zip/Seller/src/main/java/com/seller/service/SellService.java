package com.seller.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.seller.Dao.CategoryDao;
import com.seller.Dao.ItemsDao;
import com.seller.Dao.SellersDao;
import com.seller.Dao.Sub_CategoryDao;
import com.seller.entity.Category;
import com.seller.entity.Items;
import com.seller.entity.SellerDetails;
import com.seller.entity.Sub_Category;
@Service
public class SellService implements SellerService{
    @Autowired SellersDao sellerdao;
    @Autowired ItemsDao itemdao;
    @Autowired Sub_CategoryDao subDao;
    @Autowired CategoryDao categDao;
	@Override
	public SellerDetails add(SellerDetails sellerdetails) {
		return sellerdao.save(sellerdetails);
	}
	@Override
	public List<SellerDetails> getAll() {
		return sellerdao.findAll();
	}
	@Override
	public SellerDetails updateBuyer(SellerDetails sellerDetails, int sid) {
		SellerDetails sellerdetails1 = sellerdao.getOne(sid);
		sellerdetails1.setBriefAboutCompany(sellerDetails.getBriefAboutCompany());
		sellerdetails1.setContactNumber(sellerDetails.getContactNumber());
		sellerdetails1.setEmialID(sellerDetails.getEmialID());
		sellerdetails1.setGstIn(sellerDetails.getGstIn());
		sellerdetails1.setUsername(sellerDetails.getUsername());
		sellerdetails1.setWebsite(sellerDetails.getWebsite());
		sellerdetails1.setPostalAddress(sellerDetails.getPostalAddress());
		sellerdetails1.setPassword(sellerDetails.getPassword());
		return sellerdao.save(sellerdetails1);
	}
	
	//Itemss
	@Override
	public Items addItems(Items items,int sid,int subid,int catid) {
		SellerDetails sellerdetails = sellerdao.getOne(sid);
		items.setSellerDetails(sellerdetails);
		Sub_Category sub_category = subDao.getOne(subid);
		items.setSub_category(sub_category);
		Category catgory = categDao.getOne(catid);
		items.setCategory(catgory);
		return itemdao.save(items);
	}
	@Override
	public Items updateItem(Items item, int pid) {
		Items items=itemdao.getOne(pid);
		items.setDescription(item.getDescription());
		items.setManufacturer(item.getManufacturer());
		items.setModel(item.getModel());
		items.setPicture(item.getPicture());
		items.setPrice(item.getPrice());
		items.setProductName(item.getProductName());
		items.setQuantity(item.getQuantity());		
		return itemdao.save(items);
	}
	@Override
	public List<Items> getAllItems() {
		return itemdao.findAll(); 
	}
	@Override
	public String deleteItem(int iid, int sid) {
		itemdao.deleteItem(iid,sid);
		return "success";
	}
	

}
