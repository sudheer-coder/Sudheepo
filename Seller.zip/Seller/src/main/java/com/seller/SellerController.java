package com.seller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.seller.entity.Items;
import com.seller.entity.SellerDetails;
import com.seller.service.SellerService;

@RestController
public class SellerController {
	@Autowired SellerService sellerservice;
	//seller
	@RequestMapping("/getAll") public List<SellerDetails> getAll() 
	    {
			  return sellerservice.getAll(); 
	    } 
	@RequestMapping(value="/Add/seller",method=RequestMethod.POST)
	public SellerDetails add(@RequestBody SellerDetails sellerDetails) 
	{
		return sellerservice.add(sellerDetails);
	}
	@RequestMapping(value="/update/seller/{ids}",method=RequestMethod.PUT)
	public SellerDetails updateBuyer(@RequestBody SellerDetails buyerdetails,@PathVariable("ids") int sid) 
	{
		return sellerservice.updateBuyer(buyerdetails,sid);
	}
   
	
	//items
	@RequestMapping(value="/Add/items/{sid}/{subid}/{catId}",method=RequestMethod.POST)
	public Items add(@RequestBody Items items,@PathVariable("sid") int sid,@PathVariable("subid") int subid,@PathVariable("catId") int catid ) 
	{
		return sellerservice.addItems(items,sid,subid,catid);
	}
	@RequestMapping(value="/update/items/{pid}",method=RequestMethod.PUT) 
	public Items updateItem(@RequestBody Items items,@PathVariable("pid") int pid )
	{   
		
		return sellerservice.updateItem(items, pid);
	}
	@RequestMapping("/getAll/items") 
	public List<Items> getAllItems() 
    {
		  return sellerservice.getAllItems(); 
    }
	@RequestMapping(value="delete/items/{iid}/{sid}" ,method = RequestMethod.DELETE)
	public String deleteItem(@PathVariable("iid") int iid,@PathVariable("sid") int sid) 
	{
		 return sellerservice.deleteItem(iid,sid);
	}
	
}
