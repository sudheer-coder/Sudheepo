export class seller{
    username:String;
    password:String;
    gstIn:String;
    briefAboutCompany:String;
    postalAddress:String;
    website:String;
    emialID:String;
    contactNumber:number;
}


