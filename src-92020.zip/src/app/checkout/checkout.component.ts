import { Component, OnInit } from '@angular/core';
import { transactions } from '../transactions';
import { Itemservice } from '../Items.service';
import { cartitems } from '../cartitem';
import { Itemlist } from '../Itemsearch';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  cartitemses:cartitems[];
  transaction:transactions;
  transactionType:String;
  price:number;
  remarks:String;
  items:Itemlist = new Itemlist();
  quantity:number;
  itemid:number;
  constructor(private dataService: Itemservice){}

  ngOnInit(): void {
  }
  
  checkout()
  {
    console.log("in checout.ts")
    this.transaction = new transactions();
    this.transaction.remarks=this.remarks;
    this.transaction.transactionType=this.transactionType;
    this.dataService.checckout(this.transaction).subscribe(transactions=>this.transaction=transactions);
    this.dataService.getAllitems().subscribe(cartitems=>{this.cartitemses=cartitems;
      for (var product of this.cartitemses) {
        this.items.quantity=product.quantity;
        this.itemid=product.itemId;
        this.items.quantity=7;
        this.dataService.updateitems(this.items,this.itemid).subscribe(Itemlist=>this.items=Itemlist);
   }
  });
  
  }
  

}
