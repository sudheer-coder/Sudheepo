package com.example.demo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Categorys {
@Id
private int cid;
private String name;
@OneToMany(mappedBy = "category")
private List<SubCategorys> subcategory;
public Categorys() 
{ 
	
}
public Categorys(int cid, String name, List<SubCategorys> subcategory) {
	super();
	this.cid = cid;
	this.name = name;
	this.subcategory = subcategory;
}
public int getCid() {
	return cid;
}
public void setCid(int cid) {
	this.cid = cid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public List<SubCategorys> getSubcategory() {
	return subcategory;
}
public void setSubcategory(List<SubCategorys> subcategory) {
	this.subcategory = subcategory;
}
@Override
public String toString() {
	return "Category [cid=" + cid + ", name=" + name + ", subcategory=" + subcategory + "]";
}


}
