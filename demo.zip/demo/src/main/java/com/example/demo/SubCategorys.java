package com.example.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class SubCategorys {
	@Id
	private int sID;
	private String prodno;
	  @ManyToOne
	   // @JoinColumn(name="cid", nullable=false)
	    private Categorys category;
	public SubCategorys() 
	{ 
		
	}
	
	public SubCategorys(int sID, String prodno, Categorys category) {
		super();
		this.sID = sID;
		this.prodno = prodno;
		this.category = category;
	}

	public int getsID() {
		return sID;
	}
	public void setsID(int sID) {
		this.sID = sID;
	}
	public String getProdno() {
		return prodno;
	}
	public void setProdno(String prodno) {
		this.prodno = prodno;
	}
	
	public Categorys getCategory() {
		return category;
	}

	public void setCategory(Categorys category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "SubCategory [sID=" + sID + ", prodno=" + prodno + ", category=" + category + "]";
	}


}
