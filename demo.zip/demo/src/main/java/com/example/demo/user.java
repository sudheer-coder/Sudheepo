package com.example.demo;

import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class user implements Serializable{
	@Id
	@Column(name="cart_id")
	private int userId;
	private String name;
	@JsonManagedReference
	@OneToMany(fetch = FetchType.LAZY ,mappedBy = "cart")
	private List<Items> items;
	public user() 
	{ 
		
	}
	
	public user(int userId, String name, List<Items> items) {
		super();
		this.userId = userId;
		this.name = name;
		this.items = items;
	}

	public List<Items> getItems() {
		return items;
	}

	public void setItems(List<Items> items) {
		this.items = items;
	}

	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "user [userId=" + userId + ", name=" + name + ", items=" + items + "]";
	}
	
	

}
