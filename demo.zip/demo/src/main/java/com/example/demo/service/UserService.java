package com.example.demo.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


 
import com.example.demo.Categorys;
import com.example.demo.dao.Idao;

@Service
public class UserService implements Iservice {
    @Autowired
    private Idao dao;
	@Override
	public List<Categorys> getAll() {
		
		return dao.findAll() ;
	}

}
