package com.example.demo;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
public class Items implements Serializable {
	@Id
	private int itemId;
	private String itemName;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="cart_id", nullable=false)
	@JsonBackReference
	private user cart;
	public Items() 
	{ 
		
	}
	
	public Items(int itemId, String itemName, user cart) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.cart = cart;
	}

	public user getCart() {
		return cart;
	}

	public void setCart(user cart) {
		this.cart = cart;
	}

	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", itemName=" + itemName + ", cart=" + cart + "]";
	}
	 

}
