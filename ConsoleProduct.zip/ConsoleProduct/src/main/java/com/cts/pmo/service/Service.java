package com.cts.pmo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cts.pmo.controller.Product;
import com.cts.pmo.dao.ProductDao;
@Component 

public class Service {
	@Autowired
	public ProductDao productdao;
	public int add(Product product) 
	{ 
		productdao.addProduct(product);
		return 0;
	}
}
