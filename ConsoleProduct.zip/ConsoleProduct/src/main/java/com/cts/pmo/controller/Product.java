package com.cts.pmo.controller;

import org.springframework.stereotype.Component;

@Component
public class Product {
	private String proName;
	private int proQty;
	private int price;
	private int proId;
	public Product(String proName, int proQty, int price) {
		super();
		this.proName = proName;
		this.proQty = proQty;
		this.price = price;
	} 
	public String getproName() 
	{ 
		return proName;
	}
	public int proQty() 
	{ 
		return proQty;
	}
	public int price() 
	{ 
		return price;
	}
	public int proId() 
	{
		return proId;
	}
	@Override
	public String toString() {
		return "product [proName=" + proName + ", proQty=" + proQty + ", price=" + price + "]";
	}

}
