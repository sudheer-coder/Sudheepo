package com.cts.pmo.controller;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.cts.pmo.service.Service;

@Controller
@RequestMapping("/")

public class HomeController {
	  @Autowired
	   private Product product;
	  @Autowired
	  private Service serv;
	  ModelAndView mv=null;
	  
	@RequestMapping("/") 
	public String sudh(Model m) 
	{  
		m.addAttribute("product",product);
		
		return "index";
	} 
	@RequestMapping("/home")
	public ModelAndView home(@ModelAttribute("product") Product product ) 
	{ 
		serv.add(product);
		
	 mv.addObject("product","home"); 
	return mv;
	}
}

