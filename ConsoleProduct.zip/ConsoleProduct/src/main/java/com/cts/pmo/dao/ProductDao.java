package com.cts.pmo.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import com.cts.pmo.controller.Product;

@Component


public class ProductDao { 
	private DataSource ds;
	private JdbcTemplate jdbc;
		@Autowired
		public void setDs(DataSource ds) {
			this.ds=ds;
			jdbc=new JdbcTemplate(this.ds);
		}

		public int addProduct(Product product){
			int storedStatus=jdbc.update("INSERT INTO product values(?,?,?,?)",new Object[]{product.getproName(),product.proQty(),product.price(),product.proId()});
			System.out.println(storedStatus);
			return product.proId();
		}

}
