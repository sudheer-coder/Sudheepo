package com.seller;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;
import java.util.zip.Deflater;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.seller.entity.Category;
import com.seller.entity.ItemSearch;
import com.seller.entity.Items;
import com.seller.entity.SellerDetails;
import com.seller.entity.Sub_Category;
import com.seller.service.SellerService;
@CrossOrigin(origins="*")
@RestController
@RequestMapping("/seller")
public class SellerController {
	private static final Logger LOGGER = (Logger) LogManager.getLogger(SellerController.class.getName());
	 
 	
	@Autowired SellerService sellerservice;
	//seller
	@RequestMapping("/getAll") public List<SellerDetails> getAll() 
	    {
		LOGGER.debug("Debug Message Logged !!!");
		LOGGER.debug("Debug Message Logged !!!");
			  return sellerservice.getAll(); 
	    } 
	@RequestMapping(value="/Add/seller",method=RequestMethod.POST)
	public SellerDetails add(@RequestBody SellerDetails sellerDetails) 
	{
		return sellerservice.add(sellerDetails);
	}
	@RequestMapping(value="/update/seller/{ids}",method=RequestMethod.PUT)
	public SellerDetails updateBuyer(@RequestBody SellerDetails buyerdetails,@PathVariable("ids") int sid) 
	{
		return sellerservice.updateBuyer(buyerdetails,sid);
	}
   
	
	//items
	@RequestMapping(value="/Add/items/{sid}/{subid}/{catId}",method=RequestMethod.POST)
	public Items add(@RequestParam("imageFile") MultipartFile file,@PathVariable("sid") int sid,@PathVariable("subid") int subid,@PathVariable("catId") int catid,
			@RequestParam("productName") String productname,
			@RequestParam("manufacturer") String manufacturer, @RequestParam("model") String model , @RequestParam("price") String price,
			@RequestParam("quantity") String quantity, @RequestParam("description") String description ) 
					throws IOException
	{
		System.out.println("Original Image Byte Size - " + file.getBytes().length);
		  Category categoryId = new Category();
		  SellerDetails sellerId = new SellerDetails();
		  Sub_Category subCategoryId = new Sub_Category();
		  
		  sellerId.setSellerId(sid);
		  categoryId.setCategoryId(catid);
		   subCategoryId.setSubCategoryId(subid);
			
		  
		Items item = new  Items(sid,productname, manufacturer, model, Integer.parseInt(price), Integer.parseInt(quantity), description,"good",compressZLib(file.getBytes()),
				
				sellerId,categoryId,subCategoryId);
		
		return sellerservice.addItems(item,sid,subid,catid);
	}
	public static byte[] compressZLib(byte[] data) {
		Deflater deflater = new Deflater();
		deflater.setInput(data);
		deflater.finish();

		ByteArrayOutputStream outputStream = new ByteArrayOutputStream(data.length);
		byte[] buffer = new byte[1024];
		while (!deflater.finished()) {
			int count = deflater.deflate(buffer);
			outputStream.write(buffer, 0, count);
		}
		try {
			outputStream.close();
		} catch (IOException e) {
		}
		System.out.println("Compressed Image Byte Size - " + outputStream.toByteArray().length);

		return outputStream.toByteArray();
	}

	@RequestMapping(value="/update/items/{pid}",method=RequestMethod.PUT) 
	public Items updateItem(@RequestBody Items items,@PathVariable("pid") int pid )
	{   
		
		return sellerservice.updateItem(items, pid);
	}
	@RequestMapping("/getAll/items") 
	public List<Items> getAllItems() 
    {
		  return sellerservice.getAllItems(); 
    }
	@RequestMapping(value="delete/items/{iid}/{sid}" ,method = RequestMethod.DELETE)
	public String deleteItem(@PathVariable("iid") int iid,@PathVariable("sid") int sid) 
	{
		 return sellerservice.deleteItem(iid,sid);
	}
	@RequestMapping(value="/seller/search" , method=RequestMethod.POST)
	public List<Items> searchItem(@RequestBody ItemSearch itemsearch)
	{  
		System.out.println(itemsearch);
	   return sellerservice.searchItem(itemsearch);
	}
	@PutMapping("/updateqnty/{pid}")
	public Items updatequantity(@RequestBody Items items,@PathVariable("pid") int pid)
	{
		return 	sellerservice.updatequantity(items,pid);
	}
	@GetMapping("/getitembyid/{pid}")
	public Items getItemById(@PathVariable("pid") int pid)
	{
		return sellerservice.getItemById(pid);
	}
	
	
}
