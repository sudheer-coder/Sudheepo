package com.seller.entity;

import java.util.Arrays;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Items {
	
	@GeneratedValue
	@Id
	private int itemId;
	private String productName;
	private String manufacturer;
	private String model;
	private int price;
	private int quantity;
	private String description;
	@Column(name = "type")
	private String type;

	@Column(name = "picture", length = 1000000)
	private byte[] picture;
	@ManyToOne
	@JoinColumn(name = "SellerId")
	private SellerDetails sellerDetails;
	@ManyToOne
	@JoinColumn(name = "categoryId")
	private Category category;
	@ManyToOne
	@JoinColumn(name = "sub_categoryId")
	private Sub_Category sub_category;	
	public Items() 
	{ 
		
	}
	public Items(int itemId, String productName, String manufacturer, String model, int price, int quantity,
			String description, String type, byte[] picture, SellerDetails sellerDetails, Category category,
			Sub_Category sub_category) {
		super();
		this.itemId = itemId;
		this.productName = productName;
		this.manufacturer = manufacturer;
		this.model = model;
		this.price = price;
		this.quantity = quantity;
		this.description = description;
		this.type = type;
		this.picture = picture;
		this.sellerDetails = sellerDetails;
		this.category = category;
		this.sub_category = sub_category;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public String getManufacturer() {
		return manufacturer;
	}
	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}
	public String getModel() {
		return model;
	}
	public void setModel(String model) {
		this.model = model;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public byte[] getPicture() {
		return picture;
	}
	public void setPicture(byte[] picture) {
		this.picture = picture;
	}
	public SellerDetails getSellerDetails() {
		return sellerDetails;
	}
	public void setSellerDetails(SellerDetails sellerDetails) {
		this.sellerDetails = sellerDetails;
	}
	public Category getCategory() {
		return category;
	}
	public void setCategory(Category category) {
		this.category = category;
	}
	public Sub_Category getSub_category() {
		return sub_category;
	}
	public void setSub_category(Sub_Category sub_category) {
		this.sub_category = sub_category;
	}
	@Override
	public String toString() {
		return "Items [itemId=" + itemId + ", productName=" + productName + ", manufacturer=" + manufacturer
				+ ", model=" + model + ", price=" + price + ", quantity=" + quantity + ", description=" + description
				+ ", type=" + type + ", picture=" + Arrays.toString(picture) + ", sellerDetails=" + sellerDetails
				+ ", category=" + category + ", sub_category=" + sub_category + "]";
	}
			

}
