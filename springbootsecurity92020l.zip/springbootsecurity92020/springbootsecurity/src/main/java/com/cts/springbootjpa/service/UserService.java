package com.cts.springbootjpa.service;

import java.util.Arrays;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import com.cts.springbootjpa.Dao.Idao;
import com.cts.springbootjpa.Dao.ItemsDao;
import com.cts.springbootjpa.Dao.PurchaseDao;
import com.cts.springbootjpa.Dao.TransactionDao;
import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.PurchaseHistory;
import com.cts.springbootjpa.entity.TransactionHistory;



@Service(value="userService")
public class UserService implements UserDetailsService,Iservice {
    @Autowired
    private Idao dao;
    @Autowired
    private ItemsDao itemsDao;
    @Autowired
    private TransactionDao transactionDao;
    @Autowired
    private PurchaseDao purchaseDao;
    @Autowired BCryptPasswordEncoder bcryptpass;
    private int totaleprice=0;
    //login
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerDetails buyerdetails=dao.findBybuyerName(username);
		if(buyerdetails == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyerdetails.getBuyerName(), buyerdetails.getPassword(), getAuthority());

	}
	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}
   

    
     //Buyers
	@Override
	public BuyerDetails findOne(String username) {
		
		return dao.findBybuyerName(username);
	}
	
	  @Override 
	  public List<BuyerDetails> getAll() {
	  
	  return dao.findAll() ; 
	  }
	 @Override
	  public BuyerDetails add(BuyerDetails buyerdetails) {
		 buyerdetails.setPassword(bcryptpass.encode(buyerdetails.getPassword()));
		return dao.save(buyerdetails);
	 }
	 @Override
	 public BuyerDetails getUser(int id) {
		return dao.getOne(id);
	  }
	 @Override
	 public BuyerDetails updateBuyer(BuyerDetails buyerdetails,int id) {
		BuyerDetails buyerDetails1=dao.getOne(id);
		if(buyerDetails1!=null)
		{   
			int buyerId=buyerdetails.getBuyerID();
			String password=buyerdetails.getPassword();
			String EmailId=buyerdetails.getEmailId();
			Date createddate=buyerdetails.getCreatedDate();
			long mobileNo=buyerdetails.getMobileNumber();
			System.out.println("enter into if");
			buyerDetails1.setBuyerID(buyerId);
			buyerDetails1.setPassword(password);
			buyerDetails1.setEmailId(EmailId);
			buyerDetails1.setCreatedDate(createddate);
			buyerDetails1.setMobileNumber(mobileNo);
			System.out.println(buyerDetails1.getEmailId());
			
			
		}
		else 
		{ 
			
		}
	return dao.save(buyerDetails1);
	
	
	}
     
	 
	 
	//Items
	@Override
	public List<CartItems> getAllItems() {
		return itemsDao.findAll();
 	
	}
     @Override
	public CartItems addcart(CartItems cartItems,int id) {
		BuyerDetails buyerdetails=dao.getOne(id);
		System.out.println(buyerdetails.getBuyerID());
		cartItems.setBuyerDetails(buyerdetails);
		return itemsDao.save(cartItems);
	}
	@Override
	public CartItems getItem(int id) {
		return itemsDao.getOne(id);
	}
	@Override
	public CartItems updateItem(CartItems cartItems, int id) {
		CartItems cartItems1=itemsDao.getOne(id);
		if(cartItems1!=null)
		{
			
			 int itemId=cartItems.getItemId();
			 int quantity=cartItems.getQuantity();
			 int price = cartItems.getPrice();
			 cartItems1.setItemId(itemId);
			 cartItems1.setQuantity(quantity);
			 cartItems1.setPrice(price);
		}
		else
		{
			
		}
		return itemsDao.save(cartItems1);
	}
	@Override
	public void deleteByIds(int id,int bid) {
		 itemsDao.deleteById(bid);	
	}
	@Override
	public void deleteAllItem() {
		itemsDao.deleteAll();
	}

	
	//Transactions
	@Override
	public List<TransactionHistory> getAllTransaction() {
		return transactionDao.findAll();
	}
	@Override
	public TransactionHistory addcartItems(TransactionHistory transactonhistory, int id) {
        BuyerDetails buyerdetails = dao.getOne(id);
        transactonhistory.setBuyerdetails(buyerdetails);
		return transactionDao.save(transactonhistory);
	}
	@Override
	public TransactionHistory getTransaction(int id) {
		return transactionDao.getOne(id);
	}
	@Override
	public TransactionHistory updateTransaction(TransactionHistory transactionhistory, int id) {
		TransactionHistory transactionhistory1 = transactionDao.getOne(id);
		if(transactionhistory1!=null)
		{
			int transactionId=transactionhistory.getTransactionId();
			String transactionType=transactionhistory.getTransactionType();
			Date dateTime=transactionhistory.getDateTime();
			String remarks=transactionhistory.getRemarks();
			transactionhistory1.setTransactionId(transactionId);
			transactionhistory1.setTransactionType(transactionType);
			transactionhistory1.setDateTime(dateTime);
			transactionhistory1.setRemarks(remarks);
		}
		else 
		{
			
		}
		
		return transactionDao.save(transactionhistory1);
	}
	@Override
	public PurchaseHistory addPurchase(PurchaseHistory purchasehistory, int id,int ids) {
		BuyerDetails buyerDetails = dao.getOne(id);
		TransactionHistory transactionHistory = transactionDao.getOne(ids);
		purchasehistory.setBuyerdetails(buyerDetails);
		purchasehistory.setTransactionhistory(transactionHistory);
		return purchaseDao.save(purchasehistory);
	}
	@Override
	public List<PurchaseHistory> getPurchase() {
		return purchaseDao.findAll();
	}
	@Override
	public PurchaseHistory getpurchase(int id) {	
		return purchaseDao.getOne(id);
	}
	@Override
	public PurchaseHistory updatePurchase(PurchaseHistory purchasehistory, int id) {
		PurchaseHistory purchasehistory1 = purchaseDao.getOne(id);
		if(purchasehistory1!=null)
		{
			int purchaseHistoryId=purchasehistory.getPurchaseHistoryId();
			int itemId=purchasehistory.getItemId();
			Date dateTime=purchasehistory.getDateTime();
			int numberOfItems=purchasehistory.getNumberOfItems();
			String remarks=purchasehistory.getRemarks();
			purchasehistory1.setDateTime(dateTime);
			purchasehistory1.setItemId(itemId);
			purchasehistory1.setNumberOfItems(numberOfItems);
			purchasehistory1.setRemarks(remarks);
			purchasehistory1.setPurchaseHistoryId(purchaseHistoryId);
		}
		else 
		{
			
		}
		
		return purchaseDao.save(purchasehistory1);
	}
	
	
	
	
	//checkout
	@Override
	public String checkout(TransactionHistory transactionhistory,int ids) {
		 BuyerDetails buyerdetails = dao.getOne(ids);
		 transactionhistory.setBuyerdetails(buyerdetails);
		List<CartItems> cartItems= itemsDao.getByBuyerId(ids);
		for(int i = 0; i < cartItems.size(); i++)
		{   
			CartItems cartitems =cartItems.get(i);
			totaleprice=totaleprice+cartitems.getPrice();
			
		}
		transactionhistory.setPrice(totaleprice);
		transactionDao.save(transactionhistory);
		System.out.println(cartItems);
		for(int i = 0; i < cartItems.size(); i++)
		{   
			CartItems cartitems =cartItems.get(i); 
			PurchaseHistory purchasehistory = new PurchaseHistory();
			Date dateOfTransaction=transactionhistory.getDateTime();
			purchasehistory.setPurchaseHistoryId(i);
			purchasehistory.setDateTime(dateOfTransaction);
			purchasehistory.setBuyerdetails(buyerdetails);
			int itemId=cartitems.getItemId();
			purchasehistory.setItemId(itemId);
			int numberOfItems = cartitems.getQuantity();
			purchasehistory.setNumberOfItems(numberOfItems);
			purchasehistory.setRemarks("good");
			purchasehistory.setTransactionhistory(transactionhistory);
			purchaseDao.save(purchasehistory);
			itemsDao.delete(cartitems);
			
		}
		return "Success";
	}


	
	


	

}
