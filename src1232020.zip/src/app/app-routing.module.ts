import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { AdditemsComponent } from './additems/additems.component';
import { NavigationbarComponent } from './navigationbar/navigationbar.component';
import { LoginformComponent } from './loginform/loginform.component';
import { LogoutComponent } from './logout/logout.component';


const routes: Routes = [
  {path:'additem',component: AdditemsComponent},
  {path:'sellersignup',component: SellersignupComponent},
  {path:'navigation',component: NavigationbarComponent},
  {path:'Login',component: LoginformComponent},
  {path:'logout',component: LogoutComponent}

  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }