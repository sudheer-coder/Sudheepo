import { Component, OnInit, Input } from '@angular/core';
import { Itemlist } from '../Itemsearch';
import { Router } from '@angular/router';
import { Itemservice } from '../Items.service';
@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
  productName:String;
  manufacturer:String;
  model:String;
  price:number;
  quantity:number;
  description:String;
  picture:String;
  items1:Itemlist = new Itemlist();
  itemids:string;
  sellerId:number;
  constructor(private router: Router,private dataService: Itemservice){}
 @Input() items:Itemlist = new Itemlist;
  ngOnInit(): void {
  }
  updateitem() 
  { 
    console.log("in update" + this.items.itemId)
    this.itemids=String(this.items.itemId);
    window.localStorage.setItem('itemId',this.itemids);
    this.router.navigate(['additem']);
   }
   deleteitem() 
   { 
     this.sellerId=+window.localStorage.getItem('sellerid')
     console.log("in .ts");
     this.dataService.deleteitem(this.items.itemId,this.sellerId).subscribe(Itemlist=>this.items1=Itemlist  )
   }
 

 
}
