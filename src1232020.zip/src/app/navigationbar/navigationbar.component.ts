import { Component, OnInit } from '@angular/core';
import { Itemsearch1 } from '../Item';
import { Itemlist } from '../Itemsearch';
import { cartitems } from '../cartitem';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-navigationbar',
  templateUrl: './navigationbar.component.html',
  styleUrls: ['./navigationbar.component.css']
})
export class NavigationbarComponent implements OnInit {
  name:String;
  itemsearch : Itemsearch1=new Itemsearch1();
  itemlist:Itemlist[];
  items:Itemlist;
  itemId:number;
  cartitem:cartitems;
  base64Data: any;
  retrieveResonse: any;
  title="hello-world";
  
    constructor(private dataService: Itemservice){}
  ngOnInit(): void {
    
  }

    private searchCustomers() {
     // this.itemsearch= new Itemsearch1();
      this.itemsearch.prodname=this.name;
      console.log("in service method");
      this.dataService.getItemByName(this.itemsearch)
        .subscribe(Itemlist => {this.itemlist = Itemlist;
          for(let item of this.itemlist){
            item.picture = 'data:image/jpeg;base64,'+ item.picture;
          }});
        
    }
  
    onSubmit() {
      console.log("in component.ts");
      this.searchCustomers();
    }
   
}
