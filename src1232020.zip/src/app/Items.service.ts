import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { cartitems } from './cartitem';
import { ApiResponse } from './api.response';

@Injectable({
    providedIn: 'root'
  })
  export class Itemservice 
  { 
    private baseUrl = 'http://localhost:8989/mentorportal/sellerService/seller/seller/search';
    private baseUrl1 = 'http://localhost:8082/buyer/Add/items/1';
    private baseurl2 = 'http://localhost:8989/mentorportal/sellerService/seller/Add/items';
    private baseurl3 ='http://localhost:8989/mentorportal/sellerService/seller/delete/items';
    private baseurl4 ='http://localhost:8084/seller/update/items';
    private baseurl5 = 'http://localhost:8082/buyer/getAll/items';
    private baseurl6 = 'http://localhost:8082/buyer/checkout/1';
    private baseurl7 = 'http://localhost:8082/buyer/Add/buyer';
    private baseurl8 = 'http://localhost:8989/mentorportal/sellerService/seller/Add/seller';
    private baseurl9 = 'http://localhost:8082/update/items';
    private baseurl10 = 'http://localhost:8082/DeleteItem';
    private baseurl11 = 'http://localhost:8989/mentorportal/sellerService/token/generate-token';
    private baseurl12 ='http://localhost:8084/seller/updateqnty';
    private baseurl13 ='http://localhost:8084/seller/getitembyid';
    
    constructor(private http: HttpClient) { }
    //seller
    login(loginpayload:object):Observable<ApiResponse>
    {  
      console.log("in login service method");
      console.log(loginpayload);
       return this.http.post<ApiResponse>(`${this.baseurl11}`,loginpayload);
    }
    addseller(seller:object):Observable<any>
    {
      
      console.log("in sellerservice method");
      console.log(seller);
      return this.http.post(`${this.baseurl8}`,seller);
    }
    getItemByName(Itemsearch1:Object):Observable<any>
    {   
        console.log("in sevie method");
        console.log(Itemsearch1);
        console.log(this.baseUrl)
        return this.http.post(`${this.baseUrl}`,Itemsearch1);
    }
    getItemById(itemId:number):Observable<any>
    {
      console.log("in getitembyid");
      return this.http.get(`${this.baseurl13}/${itemId}`);
    }
    additems(Itemlist:object,sellerId:number):Observable<any> 
    { 
      console.log(Itemlist);
      
      return this.http.post(`${this.baseurl2}/${sellerId}/1/1`,Itemlist)
    }
    deleteitem(Itemid:number,sellerid:number):Observable<any>
    {
      console.log("enter to delete");
      return this.http.delete(`${this.baseurl3}/${Itemid}/${sellerid}`)
    }
    
    updateitems(Itemlist:object,itemid:number):Observable<any> 
    { 
      console.log(Itemlist);
      console.log(itemid);
      return this.http.put(`${this.baseurl4}/${itemid}`,Itemlist)
    }
    updatequantity(Itemlist:object,itemid:number):Observable<any>
    {
      console.log(Itemlist);
      console.log(itemid);
      return this.http.put(`${this.baseurl12}/${itemid}`,Itemlist)
    } 

   
  }