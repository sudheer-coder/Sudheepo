export class Itemlist
{   
    itemId:number;
    productName:String;
    manufacturer:String;
    model:String;
    price:number;
    quantity:number;
    description:String;
    picture:any;
    }