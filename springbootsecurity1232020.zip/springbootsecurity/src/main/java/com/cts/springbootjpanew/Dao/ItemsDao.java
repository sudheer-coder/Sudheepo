package com.cts.springbootjpanew.Dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.springbootjpanew.entity.CartItems;
@Repository
public interface ItemsDao extends JpaRepository<CartItems, Integer> {
	
	 @Modifying
	 @Transactional
	 @Query(value = "delete from cart_items  where cart_item_id=?1 and buyerid=?2",nativeQuery = true)
	  public void deleteByIds(int id, int bid);
	 @Query(value = "select * from cart_items  where buyerID=?1",nativeQuery = true)
	  public List<CartItems> getByBuyerId(int ids);
	  
}
