package com.cts.springbootjpanew.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.springbootjpanew.entity.PurchaseHistory;

public interface PurchaseDao extends JpaRepository<PurchaseHistory, Integer>{

}
