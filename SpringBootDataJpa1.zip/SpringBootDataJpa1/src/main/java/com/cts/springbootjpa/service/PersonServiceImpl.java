package com.cts.springbootjpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springbootjpa.Person;
import com.cts.springbootjpa.dao.IPersonDao;

@Service
public class PersonServiceImpl implements IPersonService {

	@Autowired
	private IPersonDao dao;//entity mgr factory
	
	@Override
	public List<Person> getAllPersons() {
	
		return dao.findAll();
				
	}

	@Override
	public Optional<Person> getById(Integer id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	@Override
	public Optional<Person> getByName(String id) {
		// TODO Auto-generated method stub
		return dao.findBypersonName(id);
	}

	@Override
	public Optional<Person> getByNameandId(Integer id, String name) {
		// TODO Auto-generated method stub
		return dao.findByNameId(id, name);
	}

	

}
