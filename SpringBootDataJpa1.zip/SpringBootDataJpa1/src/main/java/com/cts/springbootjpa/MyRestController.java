package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springbootjpa.service.IPersonService;

@RestController
public class MyRestController {
	
	@Autowired
	private IPersonService service;
	
	@RequestMapping("/getAll")
	public List<Person> getAll(){
		
		return service.getAllPersons();
	} 
	@RequestMapping("/getById/{id}")
	public Optional<Person> getById(@PathVariable("id") Integer Id)
	{
		//service.getById(Id);
		return service.getById(Id);
	}
	@RequestMapping("/getByName/{name}")
	public Optional<Person> getByName(@PathVariable("name") String Id)
	{
		//service.getById(Id);
		return service.getByName(Id);
	}
	@RequestMapping("/getByNameandId/{Id}/{name}")
	public Optional<Person> getByNameandId(@PathVariable("Id") Integer Id,@PathVariable("name") String name)
	{
		return null;
	}
}
