package com.cts.springbootjpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.Person;


public interface IPersonService{

	List<Person> getAllPersons();
	Optional<Person> getById(Integer id);
	Optional<Person> getByName(String id);
	Optional<Person> getByNameandId(Integer id,String name);
	
	
	
}
