package com.cts.springbootjpa.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.Person;
@Repository
public interface IPersonDao  extends JpaRepository<Person, Integer> {
	Optional<Person> findBypersonName(String s);
    @Query("from Person p where p.personId=:id and p.personName=:name")
    Optional<Person> findByNameId(@Param("id") Integer id,@Param("name") String name);
	
}
