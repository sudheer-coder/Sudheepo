import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {Itemservice} from './Items.service';
import { FormsModule } from '@angular/forms';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { AdditemsComponent } from './additems/additems.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { GetallcartitemsComponent } from './getallcartitems/getallcartitems.component';
import { CheckoutComponent } from './checkout/checkout.component';

//import { Itemsearch1 } from './Item';
//import {Itemlist} from './Itemsearch';

@NgModule({
  declarations: [
    AppComponent,
    ItemDetailsComponent,
    AdditemsComponent,
    UsersignupComponent,
    SellersignupComponent,
    GetallcartitemsComponent,
    CheckoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
   // Itemservice,
   //Itemsearch1,
    //Itemlist,
    HttpClientModule
  ],
  providers: [Itemservice],
  bootstrap: [AppComponent]
})
export class AppModule { }
