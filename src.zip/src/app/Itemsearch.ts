export class Itemlist
{   
    productName:String;
    manufacturer:String;
    model:String;
    price:number;
    quantity:number;
    description:String;
    picture:String;
    }