import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Itemsearch1 } from './Item';

@Injectable({
    providedIn: 'root'
  })
  export class Itemservice 
  { 
    private baseUrl = 'http://localhost:8082/seller/search';
    private baseUrl1 = 'http://localhost:8082/Add/items/1';
    private baseurl2 = 'http://localhost:8082/seller/Add/items/1/1/1';
    constructor(private http: HttpClient) { }
    //seller
    getItemByName(Itemsearch1:Object):Observable<any>
    {   
        console.log("in sevie method");
        console.log(Itemsearch1);
        
        return this.http.post(`${this.baseUrl}`,Itemsearch1);
    }
    additems(Itemlist:object):Observable<any> 
    { 
      console.log(Itemlist);
      return this.http.post(`${this.baseurl2}`,Itemlist)
    }


    //buyer
    addcartitem(cartitems:object):Observable<any>
    {
      console.log(cartitems);
      return this.http.post(`${this.baseUrl1}`,cartitems);
    }
  }