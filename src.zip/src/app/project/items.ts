export class searchName
{
    searchName:String;
}