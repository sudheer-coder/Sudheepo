export class searchName
{
    searchName:String;
    getname(id:String)
    {
      return this.searchName;
    }
    setname(id:String)
    {
        this.searchName=id;
    }

}