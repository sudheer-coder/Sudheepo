import { Component, OnInit } from '@angular/core';
import {Itemservice} from '../items.service'
import {searchName} from './items'
@Component({
  selector: 'app-project',
  templateUrl: './project.component.html',
  styleUrls: ['./project.component.css']
})
export class ProjectComponent implements OnInit {

  name:String;

  ngOnInit(): void {
    this.name = "enter name";
  }
  constructor(private dataService: Itemservice) { }
  private searchCustomers() {
    this.dataService.getCustomersByAge(this.name)
      .subscribe(customers => this.customers = customers);
  }

  onSubmit() {
    this.searchCustomers();
  }
}
