import { Component, OnInit, Input } from '@angular/core';
import { cartitems } from '../cartitem';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-getallcartitems',
  templateUrl: './getallcartitems.component.html',
  styleUrls: ['./getallcartitems.component.css']
})
export class GetallcartitemsComponent implements OnInit {
  cartitemses:cartitems[];
  cartitem1:cartitems;
  quantity:number=0;
  show:boolean=false;
  cartItemId:number;
  constructor(private dataService: Itemservice){}
  @Input() cartitem = new cartitems();
  ngOnInit(): void {
  }
  
  getallcartitems()
  { 
    this.show=true;
    this.dataService.getAllitems().subscribe(cartitems=>this.cartitemses=cartitems);
  }
  
  updatecartitem()
  {
    console.log("in update ts");
    console.log(this.quantity);
    this.cartItemId=this.cartitem.cartItemId;
    this.cartitem1 = new cartitems();
    this.cartitem1.price=this.cartitem.price;
    this.cartitem1.itemId=this.cartitem.itemId;
    this.cartitem1.quantity=this.quantity;
    this.dataService.updatecartitem(this.cartitem1,this.cartItemId).subscribe(cartitems=>this.cartitemses=cartitems);
  }
  increment()
  {
    console.log("incrementing");
    this.quantity=this.quantity+1;
  }

}
