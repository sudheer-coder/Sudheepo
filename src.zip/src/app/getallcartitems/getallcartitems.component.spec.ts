import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetallcartitemsComponent } from './getallcartitems.component';

describe('GetallcartitemsComponent', () => {
  let component: GetallcartitemsComponent;
  let fixture: ComponentFixture<GetallcartitemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetallcartitemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetallcartitemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
