import { Component, OnInit, Input } from '@angular/core';
import { Itemlist } from '../Itemsearch';
import {cartitems} from '../cartitem';
import { Itemservice } from '../Items.service';
import { transactions } from '../transactions';
@Component({
  selector: 'app-item-details',
  templateUrl: './item-details.component.html',
  styleUrls: ['./item-details.component.css']
})
export class ItemDetailsComponent implements OnInit {
  cartitem:cartitems;
  cartitemses:cartitems[];
  transaction:transactions;
  transactionType:String;
  remarks:String;
  price:number;
  constructor(private dataService: Itemservice){}
 @Input() items:Itemlist = new Itemlist;
  ngOnInit(): void {
  }
  addcart() 
  {
    this.cartitem = new cartitems();
    this.cartitem.cartItemId=5;
    this.cartitem.price=this.items.price;
    this.cartitem.quantity=this.items.quantity;
    this.dataService.addcartitem(this.cartitem).subscribe(cartitems=>this.cartitem=cartitems);

  }
  getallcartitems()
  {
    this.dataService.getAllitems().subscribe(cartitems=>this.cartitemses=cartitems);
  }
  checkout()
  {
    console.log("in checout.ts")
    this.transaction = new transactions();
    this.transaction.price=this.price;
    this.transaction.remarks=this.remarks;
    this.transaction.transactionType=this.transactionType;
    this.dataService.checckout(this.transaction).subscribe(transactions=>this.transaction=transactions);
  }

}
