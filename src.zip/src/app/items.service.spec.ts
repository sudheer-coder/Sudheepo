import { TestBed, inject } from '@angular/core/testing';

import { Itemservice } from './items.service';

describe('Itemservice', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [Itemservice]
    });
  });

  it('should be created', inject([Itemservice], (service: Itemservice) => {
    expect(service).toBeTruthy();
  }));
});
