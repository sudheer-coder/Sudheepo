export class Items
{
    
        username:String;
        password:String;
        gstIn:String;
        briefAboutCompany:String;
        postalAddress:String;
        website:String;
        emialID:String;
        contactNumber:number;
        
}