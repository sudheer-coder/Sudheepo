package com.cts.springbootjpa.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class CartItems {
	@Id
	private int cartItemId;
	private int itemId;
	private int quantity;
	private int price;
	
	@ManyToOne
	@JoinColumn(name="buyerID")
	private BuyerDetails buyerDetails;
	public CartItems() 
	{ 
		
	}
	
	public CartItems(int cartItemId, int itemId, int quantity, int price, BuyerDetails buyerDetails) {
		super();
		this.cartItemId = cartItemId;
		this.itemId = itemId;
		this.quantity = quantity;
		this.price = price;
		this.buyerDetails = buyerDetails;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}

	public int getCartItemId() {
		return cartItemId;
	}
	public void setCartItemId(int cartItemId) {
		this.cartItemId = cartItemId;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public BuyerDetails getBuyerDetails() {
		return buyerDetails;
	}
	public void setBuyerDetails(BuyerDetails buyerDetails) {
		this.buyerDetails = buyerDetails;
	}

	@Override
	public String toString() {
		return "CartItems [cartItemId=" + cartItemId + ", itemId=" + itemId + ", quantity=" + quantity + ", price="
				+ price + ", buyerDetails=" + buyerDetails + "]";
	}
	
	

}
