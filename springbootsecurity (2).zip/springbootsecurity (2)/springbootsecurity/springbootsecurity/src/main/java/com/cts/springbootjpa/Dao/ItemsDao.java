package com.cts.springbootjpa.Dao;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.entity.CartItems;
@Repository
public interface ItemsDao extends JpaRepository<CartItems, Integer> {
	
	
	 @Query(value = "delete from CartItems c where c.cartItemId=?1 and c.buyerID=?2",nativeQuery = true)
	  public void deleteByIds(int id, int bid);
	 @Query(value = "select * from cart_items  where buyerID=?1",nativeQuery = true)
	  public List<CartItems> getByBuyerId(int ids);
	  
}
