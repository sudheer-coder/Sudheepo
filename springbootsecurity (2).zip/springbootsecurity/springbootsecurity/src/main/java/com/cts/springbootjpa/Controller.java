package com.cts.springbootjpa;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.Category;
import com.cts.springbootjpa.entity.PurchaseHistory;
import com.cts.springbootjpa.entity.Sub_Category;
import com.cts.springbootjpa.entity.TransactionHistory;
import com.cts.springbootjpa.service.Iservice;


@RestController
public class Controller {
	@Autowired
	private Iservice service;

	//Buyers
    @RequestMapping("/getAll") public List<BuyerDetails> getAll() 
    {
		  return service.getAll(); 
    } 
	@RequestMapping(value="/Add/buyer",method=RequestMethod.POST)
	public BuyerDetails add(@RequestBody BuyerDetails buyerdetails) 
	{
		return service.add(buyerdetails);
	}
	@RequestMapping(value="/getUser/{ids}",method=RequestMethod.GET)
	public BuyerDetails getUser(@PathVariable("ids") int id) 
	{
		return service.getUser(id);
	}
	@RequestMapping(value="/update/buyer/{ids}",method=RequestMethod.PUT)
	public BuyerDetails updateBuyer(@RequestBody BuyerDetails buyerdetails,@PathVariable("ids") int id) 
	{
		return service.updateBuyer(buyerdetails,id);
	}
	
	//Items
	@RequestMapping("/getAll/items") 
	public List<CartItems> getAllItems() 
    {
		  return service.getAllItems(); 
    }
	@RequestMapping(value="/Add/items/{ids}",method=RequestMethod.POST)
	public CartItems add(@RequestBody CartItems cartitems,@PathVariable("ids") int id) 
	{
		return service.addcart(cartitems,id);
	}
	@RequestMapping(value="/getItem/{ids}",method=RequestMethod.GET)
	public CartItems getItem(@PathVariable("ids") int id) 
	{
		return service.getItem(id);
	}
	@RequestMapping(value="/update/items/{ids}",method=RequestMethod.PUT)
	public CartItems updateItem(@RequestBody CartItems cartitems,@PathVariable("ids") int id) 
	{
		return service.updateItem(cartitems,id);
	}
	@RequestMapping(value="/DeleteItem/{ids}",method=RequestMethod.DELETE)
	public void deleteItem(@PathVariable("ids") int id) 
	{
		 service.deleteItem(id);
	}
	@RequestMapping(value="/DeleteAllItem",method=RequestMethod.DELETE)
	public void deleteAllItem() 
	{
		 service.deleteAllItem();
	}	
	
	
	
	//transactions
	@RequestMapping("/getAll/transactions") public List<TransactionHistory> getAllTransactions() 
    {
		  return service.getAllTransaction(); 
    }
	@RequestMapping(value="/Add/transaction/{ids}",method=RequestMethod.POST)
	public TransactionHistory add(@RequestBody TransactionHistory transactionhistory,@PathVariable("ids") int id) 
	{
		return service.addcartItems(transactionhistory, id);
	}
	@RequestMapping(value="/gettransaction/{ids}",method=RequestMethod.GET)
	public TransactionHistory getTransaction(@PathVariable("ids") int id) 
	{
		return service.getTransaction(id);
	}
	@RequestMapping(value="/update/transaction/{ids}",method=RequestMethod.PUT)
	public TransactionHistory updateTransaction(@RequestBody TransactionHistory transactionhistory ,@PathVariable("ids") int id) 
	{
		return service.updateTransaction(transactionhistory,id);
	}
	
	
	//purchase
	@RequestMapping("/getAllPurchase") public List<PurchaseHistory> getPurchase() 
    {
		  return service.getPurchase(); 
    } 
	@RequestMapping(value="/Add/purchase/{ids}/{idss}",method=RequestMethod.POST)
	public PurchaseHistory add(@RequestBody PurchaseHistory purchaseHistory,@PathVariable("ids") int id,@PathVariable("idss") int ids ) 
	{
		return service.addPurchase(purchaseHistory, id,ids);
	}
	@RequestMapping(value="/getpurchase/{ids}",method=RequestMethod.GET)
	public PurchaseHistory getpurchase(@PathVariable("ids") int id) 
	{
		return service.getpurchase(id);
	}
	@RequestMapping(value="/update/purchase/{ids}",method=RequestMethod.PUT)
	public PurchaseHistory updateTransaction(@RequestBody PurchaseHistory PurchaseHistory ,@PathVariable("ids") int id) 
	{
		return service.updatePurchase(PurchaseHistory,id);
	}
	
	
	
	

}
