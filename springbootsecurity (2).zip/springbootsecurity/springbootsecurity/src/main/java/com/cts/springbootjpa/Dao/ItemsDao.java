package com.cts.springbootjpa.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.entity.CartItems;
@Repository
public interface ItemsDao extends JpaRepository<CartItems, Integer> {

}
