package com.cts.springbootjpa.Dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.Category;
import com.cts.springbootjpa.entity.Sub_Category;
@Repository
public interface Idao extends JpaRepository<BuyerDetails, Integer>{

}
