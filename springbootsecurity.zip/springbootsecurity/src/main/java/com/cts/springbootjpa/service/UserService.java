package com.cts.springbootjpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cts.springbootjpa.Dao.CategoryDao;
import com.cts.springbootjpa.Dao.Idao;
import com.cts.springbootjpa.Dao.ItemsDao;
import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.Category;


@Service
public class UserService implements Iservice {
    @Autowired
    private Idao dao;
    @Autowired
    private ItemsDao itemsDao;
    @Autowired
    private CategoryDao categoryDao;
    

	
	  @Override 
	  public List<BuyerDetails> getAll() {
	  
	  return dao.findAll() ; 
	  }
	 
	@Override
	public BuyerDetails add(BuyerDetails buyerdetails) {
		
		return dao.save(buyerdetails);
		
	}

	@Override
	public CartItems addcart(CartItems cartItems,int id) {
		BuyerDetails buyerdetails=dao.findOne(id);
		cartItems.setBuyerDetails(buyerdetails);
		return itemsDao.save(cartItems);
	}

	@Override
	public Category addCategory(Category category) {
		// TODO Auto-generated method stub
		return categoryDao.save(category);
	}

	

}
