package com.cts.springbootjpa.service;

import java.util.List;
import java.util.Optional;

import com.cts.springbootjpa.entity.BuyerDetails;
import com.cts.springbootjpa.entity.CartItems;
import com.cts.springbootjpa.entity.Category;
import com.cts.springbootjpa.entity.Sub_Category;

public interface Iservice {
    List<BuyerDetails> getAll();
	BuyerDetails add(BuyerDetails buyerdetails);
	CartItems addcart(CartItems cartItems,int id);
	Category addCategory(Category category);
	
}
