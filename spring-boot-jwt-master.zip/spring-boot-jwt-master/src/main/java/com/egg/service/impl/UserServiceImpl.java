package com.egg.service.impl;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.egg.dao.Idao;
import com.egg.dao.UserDao;
import com.egg.model.BuyerDetails;
import com.egg.model.User;
import com.egg.model.UserDto;
import com.egg.service.Iservice;
import com.egg.service.UserService;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;


@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService, Iservice {//vhange to buyer dao
	
	@Autowired
	private Idao dao;

	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		BuyerDetails buyerdetails = dao.findByUserName(username);
		if(buyerdetails == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(buyerdetails.getUserName(), buyerdetails.getPassword(), getAuthority());
	}

	private List<SimpleGrantedAuthority> getAuthority() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public List<BuyerDetails> findAll() {
		List<BuyerDetails> list = new ArrayList<>();
		dao.findAll().iterator().forEachRemaining(list::add);
		return list;
	}

	@Override
	public List<BuyerDetails> getAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

	@Override
	public BuyerDetails add(BuyerDetails buyerdetails) {
		// TODO Auto-generated method stub
		return dao.save(buyerdetails);
	}

	@Override
	public BuyerDetails getUser(int id) {
		// TODO Auto-generated method stub
		return dao.getOne(id);
	}

	@Override
	public BuyerDetails updateBuyer(BuyerDetails buyerdetails, int id) {
		BuyerDetails buyerDetails1=dao.getOne(id);
		if(buyerDetails1!=null)
		{   
			int buyerId=buyerdetails.getBuyerID();
			String password=buyerdetails.getPassword();
			String EmailId=buyerdetails.getEmailId();
			Date createddate=buyerdetails.getCreatedDate();
			long mobileNo=buyerdetails.getMobileNumber();
			System.out.println("enter into if");
			buyerDetails1.setBuyerID(buyerId);
			buyerDetails1.setPassword(password);
			buyerDetails1.setEmailId(EmailId);
			buyerDetails1.setCreatedDate(createddate);
			buyerDetails1.setMobileNumber(mobileNo);
			System.out.println(buyerDetails1.getEmailId());
			
			
		}
		else 
		{ 
			
		}
	return dao.save(buyerDetails1);
	}

	
}
