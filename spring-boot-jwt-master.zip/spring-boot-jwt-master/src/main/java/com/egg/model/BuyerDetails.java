package com.egg.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

@Entity
public class BuyerDetails {
@Id
private int buyerID;
private String password;
private String emailId;
private long mobileNumber;
@CreationTimestamp
@Temporal(TemporalType.DATE) 
private Date createdDate;
private String userName;
public BuyerDetails() 
{ 
	
}

public BuyerDetails(int buyerID, String password, String emailId, long mobileNumber, Date createdDate,
		String userName) {
	super();
	this.buyerID = buyerID;
	this.password = password;
	this.emailId = emailId;
	this.mobileNumber = mobileNumber;
	this.createdDate = createdDate;
	this.userName = userName;
}

public int getBuyerID() {
	return buyerID;
}
public void setBuyerID(int buyerID) {
	this.buyerID = buyerID;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public long getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(long mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public Date getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
}

public String getUserName() {
	return userName;
}

public void setUserName(String userName) {
	this.userName = userName;
}

@Override
public String toString() {
	return "BuyerDetails [buyerID=" + buyerID + ", password=" + password + ", emailId=" + emailId + ", mobileNumber="
			+ mobileNumber + ", createdDate=" + createdDate + ", userName=" + userName + "]";
}



}
