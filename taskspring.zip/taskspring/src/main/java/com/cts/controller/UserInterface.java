package com.cts.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@Controller
public class UserInterface{
	
	@Autowired
	ProductService pServ; 
	
	@RequestMapping(value="/admin/name/password", method = RequestMethod.GET) 
	public String adm() 
	{  
		System.out.println("enter into index");
		return "index";
	}
	
    @RequestMapping(value="/product",method=RequestMethod.GET)
    public String prod(Model m) 
    {   
    	//System.out.println("enter into add");
    	List<Product> li=pServ.prod(); 
    	//m.addAttribute("product",li);
    	return "prod";
    }
    
	
	@RequestMapping(value="/add/product",method=RequestMethod.POST,produces="application/json")
	public int addProduct(@RequestBody Product product) {
		
		return pServ.addProduct(product);
	}
	
	//GETBYIDs
	@RequestMapping(value="/getbyid/{prodId}",method=RequestMethod.GET)
	public ResponseEntity<Product> getById(@PathVariable("prodId") int prodId) {
		Product product = pServ.getById(prodId);
		if(product == null) {
			return new ResponseEntity<Product>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<Product>(product,HttpStatus.OK);
	} 
	@RequestMapping(value = "/Delete/{prodId}" , method=RequestMethod.DELETE)
	public int delete(@PathVariable("prodId") int prodId) 
	{   
		
		int rst=pServ.deleteid(prodId);
		return rst;
	}

}
