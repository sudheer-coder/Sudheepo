import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AdditemsComponent } from './additems/additems.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginformComponent } from './loginform/loginform.component';
import { SellersignupComponent } from './sellersignup/sellersignup.component';
import { FormsModule } from '@angular/forms';
import {Itemservice} from './Items.service';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    AdditemsComponent,
    LoginformComponent,
    SellersignupComponent,
    HttpClientModule
   
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [Itemservice],
  bootstrap: [AppComponent]
})
export class AppModule { }
