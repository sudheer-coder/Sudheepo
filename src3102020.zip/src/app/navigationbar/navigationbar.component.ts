import { Component, OnInit } from '@angular/core';
import { Itemsearch1 } from '../Item';
import { Itemlist } from '../Itemsearch';
import { cartitems } from '../cartitem';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-navigationbar',
  templateUrl: './navigationbar.component.html',
  styleUrls: ['./navigationbar.component.css']
})
export class NavigationbarComponent implements OnInit {
  name:String;
  itemsearch : Itemsearch1;
  itemlist:Itemlist[];
  items:Itemlist;
  itemId:number;
  cartitem:cartitems;
  title="hello-world";
  
    constructor(private dataService: Itemservice){}
  ngOnInit(): void {
    throw new Error("Method not implemented.");
  }
    
    private searchCustomers() {
      this.itemsearch= new Itemsearch1();
      this.itemsearch.prodname=this.name;
      console.log("in service method");
      this.dataService.getItemByName(this.itemsearch)
        .subscribe(Itemlist => this.itemlist = Itemlist);
        
    }
  
    onSubmit() {
      console.log("in component.ts");
      this.searchCustomers();
    }
    addcart() 
    {
      this.cartitem = new cartitems();
      this.items = new Itemlist();
      this.cartitem.cartItemId=6;
     
     // this.cartitem.price=this.itemlist.price;
      //his.cartitem.quantity=this.itemlist.quantity;
      this.dataService.addcartitem(this.cartitem).subscribe(cartitems=>this.cartitem=cartitems);
  
    }
  
}
