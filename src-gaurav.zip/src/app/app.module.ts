import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import {Itemservice} from './Items.service';
import { FormsModule } from '@angular/forms';
import { ItemDetailsComponent } from './item-details/item-details.component';
import { UsersignupComponent } from './usersignup/usersignup.component';
import { GetallcartitemsComponent } from './getallcartitems/getallcartitems.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { LoginformComponent } from './loginform/loginform.component';
import { NavigationbarComponent } from './navigationbar/navigationbar.component';
import { TokenInterceptor } from './interceptor';
import { LogoutComponent } from './logout/logout.component';




//import { Itemsearch1 } from './Item';
//import {Itemlist} from './Itemsearch';

@NgModule({
  declarations: [
    AppComponent,
    ItemDetailsComponent,
    UsersignupComponent,
    GetallcartitemsComponent,
    CheckoutComponent,
    LoginformComponent,
    NavigationbarComponent,
    LogoutComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
   // Itemservice,
   //Itemsearch1,
    //Itemlist,
    HttpClientModule
  ],
  providers: [Itemservice,{provide: HTTP_INTERCEPTORS,
    useClass: TokenInterceptor,
    multi : true}],
  bootstrap: [AppComponent]
})
export class AppModule { }
