import { Component, OnInit, Input } from '@angular/core';
import { cartitems } from '../cartitem';
import { Itemservice } from '../Items.service';

@Component({
  selector: 'app-getallcartitems',
  templateUrl: './getallcartitems.component.html',
  styleUrls: ['./getallcartitems.component.css']
})
export class GetallcartitemsComponent implements OnInit {
  cartitemses:cartitems[];
  cartitem1:cartitems;
  quantity:number=0;
  show:boolean=false;
  cartItemId:number;
  totalprice:number=0;
  price:number=1000;
  constructor(private dataService: Itemservice){}
  @Input() cartitem = new cartitems();
  ngOnInit(): void {
    this.dataService.getAllitems().subscribe(cartitems=>{this.cartitemses=cartitems;
      this.cartitemses.forEach(element => { 
        this.totalprice = this.totalprice+(element.price*element.quantity)
     });
    });
    
    
  }
  
  increment(items:cartitems)
  {
    window.location.reload(true);
    console.log("incrementing");
    items.quantity=items.quantity+1;
    this.price = this.price*items.quantity;
    this.cartItemId=items.cartItemId;
    this.cartitem1 = new cartitems();
    this.cartitem1.quantity=items.quantity;
    this.cartitem1.price=this.price;
    this.dataService.updatecartitem(this.cartitem1,this.cartItemId).subscribe(cartitems=>this.cartitemses=cartitems);
    console.log(items.price);
  }
  decrement(items:cartitems)
  {
    window.location.reload(true);
    console.log("decrement");
    items.quantity=items.quantity-1;
    this.price = this.price*items.quantity;
    this.cartItemId=items.cartItemId;
    this.cartitem1 = new cartitems();
    this.cartitem1.quantity=items.quantity;
    this.cartitem1.price=this.price;
    this.dataService.updatecartitem(this.cartitem1,this.cartItemId).subscribe(cartitems=>this.cartitemses=cartitems);

  }
  delete(items:cartitems)
  { 
    window.location.reload(true);
    console.log("in delete");
    console.log(items.cartItemId);
    this.dataService.deletecartitem(items.cartItemId).subscribe(cartitems=>this.cartitemses=cartitems);
  }

}
