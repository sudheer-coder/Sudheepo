import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { Itemservice } from '../Items.service';
@Component({
  selector: 'app-loginform',
  templateUrl: './loginform.component.html',
  styleUrls: ['./loginform.component.css']
})
export class LoginformComponent implements OnInit {
  username:String;
  password:String;
  constructor(private router: Router,private dataService: Itemservice) { }
  login()
  {
    console.log("in login method");
    const loginPayload = {
    username: this.username,
    password: this.password
  }
  this.dataService.login(loginPayload).subscribe(data => {
    debugger;
    if(data.result.token !== null) {
      alert("successs");
      console.log("in subscribe method");
      window.localStorage.setItem('token', data.result.token);
      window.localStorage.setItem('buyerid', data.result.buyerid);
      window.localStorage.setItem('buyername', data.result.username);
      console.log(data.result.token);
      this.router.navigate(['navigation/cartitems']);
    }else {
      
      alert("incorrect password");
    }
  });
  }

  ngOnInit(): void {
  }

}
