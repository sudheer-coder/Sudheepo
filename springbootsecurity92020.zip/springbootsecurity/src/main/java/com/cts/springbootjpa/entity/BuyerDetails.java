package com.cts.springbootjpa.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;



@Entity
public class BuyerDetails {
@Id
@GeneratedValue
private int buyerID;
private String password;
private String emailId;
private long mobileNumber;
@CreationTimestamp
@Temporal(TemporalType.TIMESTAMP)
private Date  createdDate;
public BuyerDetails() 
{ 
	
}
public BuyerDetails(int buyerID, String password, String emailId, long mobileNumber, Date createdDate) {
	super();
	this.buyerID = buyerID;
	this.password = password;
	this.emailId = emailId;
	this.mobileNumber = mobileNumber;
	this.createdDate = createdDate;
}
public int getBuyerID() {
	return buyerID;
}
public void setBuyerID(int buyerID) {
	this.buyerID = buyerID;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public long getMobileNumber() {
	return mobileNumber;
}
public void setMobileNumber(long mobileNumber) {
	this.mobileNumber = mobileNumber;
}
public Date getCreatedDate() {
	return createdDate;
}
public void setCreatedDate(Date createdDate) {
	this.createdDate = createdDate;
}
@Override
public String toString() {
	return "BuyerDetails [buyerID=" + buyerID + ", password=" + password + ", emailId=" + emailId + ", mobileNumber="
			+ mobileNumber + ", createdDate=" + createdDate + "]";
}

}
